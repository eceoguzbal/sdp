
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import warnings
warnings.filterwarnings('ignore')

# Import custom modules
import sys
sys.path.append('.')
import config
from modules.data_loader import DataLoader
from modules.statistical_models import StatisticalForecaster
from modules.ml_models import MLPipeline, create_ml_forecasts
from modules.ensemble import EnsembleForecaster, create_ensemble_forecast
from modules.stochastic_simulation import MonteCarloSimulator
from modules.portfolio_optimizer import PortfolioOptimizer
from modules.backtesting import Backtester
from modules.evaluation import ModelEvaluator

# Page configuration
st.set_page_config(
    page_title=config.PAGE_TITLE,
    page_icon=config.PAGE_ICON,
    layout=config.LAYOUT,
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .sub-header {
        font-size: 1.5rem;
        color: #ff7f0e;
        margin-top: 2rem;
        margin-bottom: 1rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'data_loaded' not in st.session_state:
    st.session_state.data_loaded = False
if 'models_trained' not in st.session_state:
    st.session_state.models_trained = False

# Main title
st.markdown('<div class="main-header">📈 STOKASPORT</div>', unsafe_allow_html=True)
st.markdown('<p style="text-align: center; font-size: 1.2rem;">AI-Powered Dynamic Portfolio Optimization System</p>', unsafe_allow_html=True)

# Sidebar
st.sidebar.title("⚙️ Configuration")
st.sidebar.markdown("---")

# User inputs
investment_amount = st.sidebar.number_input(
    "💰 Investment Amount ($)",
    min_value=1000,
    max_value=10000000,
    value=100000,
    step=1000
)

risk_tolerance = st.sidebar.selectbox(
    "🎯 Risk Tolerance",
    options=['Low', 'Medium', 'High'],
    index=1
)

prediction_horizon = st.sidebar.selectbox(
    "📅 Prediction Horizon",
    options=[1, 5],
    format_func=lambda x: f"{x} day(s)",
    index=0
)

st.sidebar.markdown("---")
st.sidebar.markdown("### 📊 Analysis Options")

run_monte_carlo = st.sidebar.checkbox("Run Monte Carlo Simulation", value=True)
generate_efficient_frontier = st.sidebar.checkbox("Generate Efficient Frontier", value=True)

st.sidebar.markdown("---")

# Main content tabs
tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "📁 Data Overview",
    "🤖 Model Training",
    "📈 Predictions",
    "💼 Portfolio Optimization",
    "🔄 Backtesting",
    "📊 Performance Analysis"
])

# TAB 1: Data Overview
with tab1:
    st.markdown('<div class="sub-header">📁 Data Overview</div>', unsafe_allow_html=True)
    
    if st.button("🔄 Load Data", type="primary", key="load_data_btn"):
        with st.spinner("Loading data from JSON files..."):
            try:
                loader = DataLoader()
                st.session_state.loader = loader
                st.session_state.asset_data = loader.load_all_assets()
                st.session_state.combined_df = loader.get_combined_dataframe()
                st.session_state.returns_df = loader.calculate_returns(st.session_state.combined_df)
                st.session_state.data_loaded = True
                st.success(f"✅ Successfully loaded {len(st.session_state.asset_data)} assets!")
            except Exception as e:
                st.error(f"❌ Error loading data: {e}")
    
    if st.session_state.data_loaded:
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Assets", len(st.session_state.asset_data))
        with col2:
            st.metric("Date Range", 
                     f"{st.session_state.combined_df.index[0].date()} to {st.session_state.combined_df.index[-1].date()}")
        with col3:
            st.metric("Total Observations", len(st.session_state.combined_df))
        
        # Asset summary
        st.markdown("### 📋 Asset Summary")
        summary = st.session_state.loader.get_data_summary()
        st.dataframe(summary, use_container_width=True)
        
        # Price visualization
        st.markdown("### 📊 Price History")
        selected_assets = st.multiselect(
            "Select assets to visualize:",
            options=st.session_state.combined_df.columns.tolist(),
            default=st.session_state.combined_df.columns.tolist()[:5]
        )
        
        if selected_assets:
            fig = go.Figure()
            for asset in selected_assets:
                fig.add_trace(go.Scatter(
                    x=st.session_state.combined_df.index,
                    y=st.session_state.combined_df[asset],
                    mode='lines',
                    name=asset
                ))
            fig.update_layout(
                title="Asset Price History",
                xaxis_title="Date",
                yaxis_title="Price",
                height=500,
                hovermode='x unified'
            )
            st.plotly_chart(fig, use_container_width=True)
        
        # Returns distribution
        st.markdown("### 📈 Returns Distribution")
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Returns Statistics**")
            returns_stats = st.session_state.returns_df.describe().T
            st.dataframe(returns_stats, use_container_width=True)
        
        with col2:
            st.write("**Correlation Matrix**")
            corr_matrix = st.session_state.returns_df.corr()
            fig_corr = px.imshow(
                corr_matrix,
                labels=dict(color="Correlation"),
                color_continuous_scale="RdBu",
                aspect="auto"
            )
            fig_corr.update_layout(height=400)
            st.plotly_chart(fig_corr, use_container_width=True)
# TAB 2: Model Training
# TAB 2: Model Training
with tab2:
    st.markdown('<div class="sub-header">🤖 Model Training</div>', unsafe_allow_html=True)
    
    if not st.session_state.data_loaded:
        st.warning("⚠️ Please load data first in the Data Overview tab.")
    else:
        st.markdown("""
        This system trains the following models:
        - **Statistical Models**: ARIMA, SARIMA, VAR
        - **Machine Learning Models**: XGBoost, LightGBM
        - **Ensemble**: Performance-weighted combination
        """)
        
        if st.button("🚀 Train All Models", type="primary", key="train_models_btn"):
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            try:
                # Select subset of assets for faster training
                n_assets_to_train = min(10, len(st.session_state.combined_df.columns))
                selected_train_assets = st.session_state.combined_df.columns[:n_assets_to_train].tolist()
                
                st.info(f"Training models on {n_assets_to_train} assets for demonstration...")
                
                # Train statistical models
                status_text.text("Training statistical models...")
                progress_bar.progress(0.2)
                
                stat_forecaster = StatisticalForecaster()
                for asset in selected_train_assets:
                    stat_forecaster.fit_all_models(st.session_state.combined_df, asset)
                stat_forecaster.fit_var_model(st.session_state.combined_df[selected_train_assets])
                
                st.session_state.stat_forecaster = stat_forecaster
                progress_bar.progress(0.5)
                
                # Train ML models
                status_text.text("Training machine learning models...")
                ml_models, ml_predictions = create_ml_forecasts(
                    st.session_state.combined_df[selected_train_assets],
                    selected_train_assets,
                    horizon=prediction_horizon
                )
                
                st.session_state.ml_models = ml_models
                st.session_state.ml_predictions = ml_predictions
                st.session_state.trained_assets = selected_train_assets
                
                progress_bar.progress(1.0)
                status_text.text("✅ Training complete!")
                st.session_state.models_trained = True
                
            except Exception as e:
                st.error(f"❌ Error training models: {e}")

        # MODELLER EĞİTİLDİYSE GÖRSELLEŞTİRME
        if st.session_state.get('models_trained', False):
            st.markdown("### 📋 Model Summary & Distribution")
            summary_df = st.session_state.stat_forecaster.get_model_summary()
            
            col1, col2 = st.columns([1, 1])
            with col1:
                st.dataframe(summary_df, use_container_width=True)
            
            with col2:
                # Modellerin türlerine göre dağılım grafiği
                fig_dist = px.pie(summary_df, names='Type', title="Model Türü Dağılımı", hole=0.4)
                st.plotly_chart(fig_dist, use_container_width=True)

# TAB 3: Predictions
with tab3:
    st.markdown('<div class="sub-header">📈 Price Predictions & Comparison</div>', unsafe_allow_html=True)
    
    if not st.session_state.get('models_trained', False):
        st.warning("⚠️ Please train models first in the Model Training tab.")
    else:
        selected_asset_pred = st.selectbox(
            "Select Asset for Prediction Visualization:",
            options=st.session_state.trained_assets
        )
        
        if st.button("🔮 Generate Forecast Graphics", key="generate_predictions_btn"):
            with st.spinner("Generating interactive charts..."):
                try:
                    # Tahminleri al
                    stat_preds = st.session_state.stat_forecaster.predict_all(steps=prediction_horizon)
                    ml_preds = st.session_state.ml_predictions[selected_asset_pred]
                    
                    # Grafik hazırlığı
                    fig = go.Figure()
                    
                    # 1. Gerçek Geçmiş Veri (Son 30 Gün)
                    actual_series = st.session_state.combined_df[selected_asset_pred].tail(30)
                    fig.add_trace(go.Scatter(
                        x=actual_series.index, 
                        y=actual_series.values, 
                        name='Gerçek Fiyat',
                        line=dict(color='black', width=3)
                    ))
                    
                    # Gelecek tarihler
                    last_date = actual_series.index[-1]
                    future_dates = pd.date_range(start=last_date + pd.Timedelta(days=1), periods=prediction_horizon, freq='D')
                    
                    # 2. İstatistiksel Tahminleri Ekle (ARIMA & SARIMA)
                    for model_key in [f'{selected_asset_pred}_ARIMA', f'{selected_asset_pred}_SARIMA']:
                        if model_key in stat_preds and stat_preds[model_key] is not None:
                            fig.add_trace(go.Scatter(
                                x=future_dates, 
                                y=stat_preds[model_key], 
                                name=model_key.split('_')[-1] + " Tahmini",
                                line=dict(dash='dash')
                            ))
                    
                    # 3. ML Tahminlerini Ekle (XGBoost & LightGBM)
                    for ml_key, ml_val in ml_preds.items():
                        fig.add_trace(go.Scatter(
                            x=future_dates, 
                            y=ml_val[:prediction_horizon], 
                            name=ml_key + " Tahmini",
                            line=dict(dash='dot')
                        ))

                    fig.update_layout(
                        title=f"{selected_asset_pred} - Çoklu Model Tahmin Karşılaştırması",
                        xaxis_title="Tarih",
                        yaxis_title="Fiyat",
                        hovermode="x unified",
                        height=600
                    )
                    st.plotly_chart(fig, use_container_width=True)

                    # Tahmin Tablosu
                    st.markdown("### 📋 Prediction Data Points")
                    all_preds_df = pd.DataFrame(index=[f"Day {i+1}" for i in range(prediction_horizon)])
                    for k, v in stat_preds.items():
                        if selected_asset_pred in k: all_preds_df[k.split('_')[-1]] = v
                    for k, v in ml_preds.items():
                        all_preds_df[k] = v[:prediction_horizon]
                    
                    st.table(all_preds_df)

                except Exception as e:
                    st.error(f"❌ Error: {e}")
# TAB 4: Portfolio Optimization
with tab4:
    st.markdown('<div class="sub-header">💼 Portfolio Optimization</div>', unsafe_allow_html=True)
    
    if not st.session_state.data_loaded:
        st.warning("⚠️ Please load data first.")
    else:
        st.markdown("""
        ### Optimization Strategy
        - **Objective**: Maximize Sharpe Ratio
        - **Constraints**: Long-only portfolio with position limits
        - **Risk Adjustment**: Based on selected risk tolerance
        """)
        
        if st.button("⚡ Optimize Portfolio", type="primary", key="optimize_portfolio_btn"):
            with st.spinner("Optimizing portfolio..."):
                try:
                    # Calculate expected returns and covariance
                    returns_df = st.session_state.returns_df
                    expected_returns = returns_df.mean().values
                    cov_matrix = returns_df.cov().values
                    
                    # Initialize optimizer
                    optimizer = PortfolioOptimizer()
                    
                    # Get risk parameters
                    risk_params = config.RISK_TOLERANCE[risk_tolerance]
                    max_weight = risk_params['max_weight']
                    
                    # Optimize for maximum Sharpe ratio
                    optimal_weights = optimizer.optimize_sharpe_ratio(
                        expected_returns,
                        cov_matrix,
                        min_weight=config.MIN_WEIGHT,
                        max_weight=max_weight
                    )
                    
                    # Apply risk tolerance adjustment
                    adjusted_weights = optimizer.apply_risk_tolerance(
                        optimal_weights,
                        risk_level=risk_tolerance
                    )
                    
                    # Calculate portfolio metrics
                    p_return, p_std, sharpe = optimizer.calculate_portfolio_metrics(
                        adjusted_weights,
                        expected_returns,
                        cov_matrix
                    )
                    
                    # Store results
                    st.session_state.optimal_weights = adjusted_weights
                    st.session_state.optimizer = optimizer
                    
                    # Display results
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Expected Annual Return", 
                                f"{p_return * config.TRADING_DAYS_PER_YEAR * 100:.2f}%")
                    with col2:
                        st.metric("Annual Volatility",
                                f"{p_std * np.sqrt(config.TRADING_DAYS_PER_YEAR) * 100:.2f}%")
                    with col3:
                        st.metric("Sharpe Ratio", f"{sharpe:.3f}")
                    
                    # Portfolio allocation
                    st.markdown("### 📊 Portfolio Allocation")
                    
                    # Create portfolio DataFrame
                    portfolio_df = pd.DataFrame({
                        'Asset': returns_df.columns,
                        'Weight': adjusted_weights,
                        'Allocation ($)': adjusted_weights * investment_amount
                    })
                    portfolio_df = portfolio_df[portfolio_df['Weight'] > 0.001].sort_values('Weight', ascending=False)
                    
                    col1, col2 = st.columns([1, 1])
                    
                    with col1:
                        st.dataframe(portfolio_df, use_container_width=True)
                    
                    with col2:
                        # Pie chart
                        fig_pie = go.Figure(data=[go.Pie(
                            labels=portfolio_df['Asset'],
                            values=portfolio_df['Weight'],
                            hole=0.3
                        )])
                        fig_pie.update_layout(title="Portfolio Weights", height=400)
                        st.plotly_chart(fig_pie, use_container_width=True)
                    
                    # Efficient Frontier
                    if generate_efficient_frontier:
                        st.markdown("### 📈 Efficient Frontier")
                        with st.spinner("Generating efficient frontier..."):
                            frontier_df = optimizer.generate_efficient_frontier(
                                expected_returns,
                                cov_matrix,
                                n_points=50
                            )
                            
                            fig_ef = go.Figure()
                            fig_ef.add_trace(go.Scatter(
                                x=frontier_df['Volatility'],
                                y=frontier_df['Return'],
                                mode='lines',
                                name='Efficient Frontier',
                                line=dict(color='blue', width=2)
                            ))
                            
                            # Mark optimal portfolio
                            fig_ef.add_trace(go.Scatter(
                                x=[p_std * np.sqrt(config.TRADING_DAYS_PER_YEAR)],
                                y=[p_return * config.TRADING_DAYS_PER_YEAR],
                                mode='markers',
                                name='Optimal Portfolio',
                                marker=dict(color='red', size=12, symbol='star')
                            ))
                            
                            fig_ef.update_layout(
                                title='Efficient Frontier',
                                xaxis_title='Volatility (Annual)',
                                yaxis_title='Return (Annual)',
                                height=500,
                                hovermode='closest'
                            )
                            st.plotly_chart(fig_ef, use_container_width=True)
                    
                    # Monte Carlo Simulation
                    if run_monte_carlo:
                        st.markdown("### 🎲 Monte Carlo Simulation")
                        with st.spinner("Running Monte Carlo simulation..."):
                            simulator = MonteCarloSimulator(
                                n_simulations=config.MC_SIMULATIONS,
                                time_horizon=config.MC_TIME_HORIZON
                            )
                            
                            # Simulate portfolio
                            portfolio_paths = simulator.simulate_portfolio(
                                st.session_state.combined_df,
                                adjusted_weights,
                                returns_df
                            )
                            
                            # Scale by investment amount
                            portfolio_paths_scaled = portfolio_paths * investment_amount
                            
                            # Get statistics
                            sim_stats = simulator.get_simulation_statistics(portfolio_paths_scaled)
                            
                            # Display metrics
                            col1, col2, col3, col4 = st.columns(4)
                            with col1:
                                st.metric("Mean Final Value", f"${sim_stats['Mean_Final_Value']:,.0f}")
                            with col2:
                                st.metric("Median Final Value", f"${sim_stats['Median_Final_Value']:,.0f}")
                            with col3:
                                st.metric("95% VaR", f"${sim_stats['VaR_95'] * investment_amount:,.0f}")
                            with col4:
                                st.metric("95% CVaR", f"${sim_stats['CVaR_95'] * investment_amount:,.0f}")
                            
                            # Plot simulation paths
                            lower, median, upper = simulator.get_confidence_intervals(
                                portfolio_paths_scaled,
                                confidence_level=0.95
                            )
                            
                            fig_mc = go.Figure()
                            
                            # Add sample paths
                            for i in range(min(100, config.MC_SIMULATIONS)):
                                fig_mc.add_trace(go.Scatter(
                                    y=portfolio_paths_scaled[i],
                                    mode='lines',
                                    line=dict(color='lightgray', width=0.5),
                                    showlegend=False,
                                    hoverinfo='skip'
                                ))
                            
                            # Add confidence intervals
                            fig_mc.add_trace(go.Scatter(
                                y=upper,
                                mode='lines',
                                name='95% Upper Bound',
                                line=dict(color='red', width=2, dash='dash')
                            ))
                            fig_mc.add_trace(go.Scatter(
                                y=median,
                                mode='lines',
                                name='Median',
                                line=dict(color='blue', width=3)
                            ))
                            fig_mc.add_trace(go.Scatter(
                                y=lower,
                                mode='lines',
                                name='95% Lower Bound',
                                line=dict(color='red', width=2, dash='dash')
                            ))
                            
                            fig_mc.update_layout(
                                title=f'Monte Carlo Simulation ({config.MC_SIMULATIONS} paths, {config.MC_TIME_HORIZON} days)',
                                xaxis_title='Trading Days',
                                yaxis_title='Portfolio Value ($)',
                                height=500,
                                showlegend=True
                            )
                            st.plotly_chart(fig_mc, use_container_width=True)
                    
                    st.success("✅ Portfolio optimization complete!")
                    
                except Exception as e:
                    st.error(f"❌ Error optimizing portfolio: {e}")
                    import traceback
                    st.code(traceback.format_exc())

# TAB 5: Backtesting
with tab5:
    st.markdown('<div class="sub-header">🔄 Backtesting</div>', unsafe_allow_html=True)
    
    if not st.session_state.data_loaded:
        st.warning("⚠️ Please load data first.")
    else:
        st.markdown("""
        ### Walk-Forward Backtesting
        - **Method**: Rolling window validation
        - **Window Size**: 252 trading days (1 year)
        - **Rebalancing**: Weekly (5 trading days)
        """)
        
        if st.button("🔬 Run Backtest", type="primary", key="run_backtest_btn"):
            with st.spinner("Running backtest..."):
                try:
                    # Initialize backtester
                    backtester = Backtester(
                        window_size=config.WALK_FORWARD_WINDOW,
                        rebalance_freq=config.REBALANCING_FREQ
                    )
                    
                    # Create optimization function
                    optimizer = PortfolioOptimizer()
                    
                    def optimization_func(expected_returns, cov_matrix):
                        weights = optimizer.optimize_sharpe_ratio(
                            expected_returns,
                            cov_matrix,
                            max_weight=config.RISK_TOLERANCE[risk_tolerance]['max_weight']
                        )
                        return weights
                    
                    # Run walk-forward validation
                    results, weights_history = backtester.walk_forward_validation(
                        st.session_state.combined_df,
                        optimization_func
                    )
                    
                    st.session_state.backtest_results = results
                    st.session_state.backtester = backtester
                    
                    # Calculate performance metrics
                    metrics = backtester.calculate_performance_metrics()
                    
                    # Display metrics
                    st.markdown("### 📊 Performance Metrics")
                    
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Cumulative Return", f"{metrics['Cumulative_Return']*100:.2f}%")
                        st.metric("Annualized Return", f"{metrics['Annualized_Return']*100:.2f}%")
                    with col2:
                        st.metric("Annualized Volatility", f"{metrics['Annualized_Volatility']*100:.2f}%")
                        st.metric("Sharpe Ratio", f"{metrics['Sharpe_Ratio']:.3f}")
                    with col3:
                        st.metric("Max Drawdown", f"{metrics['Max_Drawdown']*100:.2f}%")
                        st.metric("Win Rate", f"{metrics['Win_Rate']*100:.2f}%")
                    
                    # Plot cumulative returns
                    st.markdown("### 📈 Cumulative Returns")
                    fig_cum = go.Figure()
                    fig_cum.add_trace(go.Scatter(
                        x=results.index,
                        y=results['Cumulative_Return'],
                        mode='lines',
                        name='Portfolio',
                        line=dict(color='blue', width=2)
                    ))
                    fig_cum.update_layout(
                        title='Portfolio Cumulative Returns',
                        xaxis_title='Date',
                        yaxis_title='Cumulative Return',
                        height=500,
                        hovermode='x unified'
                    )
                    st.plotly_chart(fig_cum, use_container_width=True)
                    
                    # Plot drawdown
                    st.markdown("### 📉 Drawdown Analysis")
                    drawdown = backtester.get_drawdown_series()
                    
                    fig_dd = go.Figure()
                    fig_dd.add_trace(go.Scatter(
                        x=drawdown.index,
                        y=drawdown.values * 100,
                        mode='lines',
                        fill='tozeroy',
                        name='Drawdown',
                        line=dict(color='red', width=1)
                    ))
                    fig_dd.update_layout(
                        title='Portfolio Drawdown',
                        xaxis_title='Date',
                        yaxis_title='Drawdown (%)',
                        height=400,
                        hovermode='x unified'
                    )
                    st.plotly_chart(fig_dd, use_container_width=True)
                    
                    # Comparison with benchmarks
                    st.markdown("### 🎯 Strategy Comparison")
                    
                    # Calculate equal-weight portfolio
                    equal_weights = np.ones(len(st.session_state.combined_df.columns)) / len(st.session_state.combined_df.columns)
                    equal_weight_returns = (st.session_state.returns_df.values @ equal_weights)
                    equal_weight_returns = pd.Series(
                        equal_weight_returns,
                        index=st.session_state.returns_df.index
                    )
                    
                    # Align with backtest dates
                    aligned_ew_returns = equal_weight_returns.loc[results.index]
                    
                    # Compare strategies
                    strategies = {
                        'Optimized Portfolio': results['Portfolio_Return'],
                        'Equal Weight': aligned_ew_returns
                    }
                    
                    comparison = backtester.compare_strategies(strategies)
                    st.dataframe(comparison, use_container_width=True)
                    
                    st.success("✅ Backtesting complete!")
                    
                except Exception as e:
                    st.error(f"❌ Error running backtest: {e}")
                    import traceback
                    st.code(traceback.format_exc())

# TAB 6: Performance Analysis
with tab6:
    st.markdown('<div class="sub-header">📊 Performance Analysis</div>', unsafe_allow_html=True)
    
    if 'backtest_results' not in st.session_state:
        st.warning("⚠️ Please run backtesting first.")
    else:
        st.markdown("### 📈 Detailed Analysis")
        
        results = st.session_state.backtest_results
        backtester = st.session_state.backtester
        
        # Rolling metrics
        rolling_window = st.slider("Rolling Window (days)", 30, 252, 60)
        
        rolling_metrics = backtester.calculate_rolling_metrics(window=rolling_window)
        
        # Plot rolling Sharpe ratio
        fig_rolling = make_subplots(
            rows=3, cols=1,
            subplot_titles=('Rolling Return', 'Rolling Volatility', 'Rolling Sharpe Ratio'),
            vertical_spacing=0.1
        )
        
        fig_rolling.add_trace(
            go.Scatter(x=rolling_metrics.index, y=rolling_metrics['Rolling_Return'],
                      mode='lines', name='Rolling Return'),
            row=1, col=1
        )
        
        fig_rolling.add_trace(
            go.Scatter(x=rolling_metrics.index, y=rolling_metrics['Rolling_Volatility'],
                      mode='lines', name='Rolling Volatility', line=dict(color='orange')),
            row=2, col=1
        )
        
        fig_rolling.add_trace(
            go.Scatter(x=rolling_metrics.index, y=rolling_metrics['Rolling_Sharpe'],
                      mode='lines', name='Rolling Sharpe', line=dict(color='green')),
            row=3, col=1
        )
        
        fig_rolling.update_layout(height=800, showlegend=False, hovermode='x unified')
        st.plotly_chart(fig_rolling, use_container_width=True)
        
        # Returns distribution
        st.markdown("### 📊 Returns Distribution")
        
        col1, col2 = st.columns(2)
        
        with col1:
            fig_hist = go.Figure()
            fig_hist.add_trace(go.Histogram(
                x=results['Portfolio_Return'] * 100,
                nbinsx=50,
                name='Returns'
            ))
            fig_hist.update_layout(
                title='Daily Returns Distribution',
                xaxis_title='Return (%)',
                yaxis_title='Frequency',
                height=400
            )
            st.plotly_chart(fig_hist, use_container_width=True)
        
        with col2:
            # QQ plot data
            from scipy import stats
            returns_sorted = np.sort(results['Portfolio_Return'])
            theoretical_quantiles = stats.norm.ppf(np.linspace(0.01, 0.99, len(returns_sorted)))
            
            fig_qq = go.Figure()
            fig_qq.add_trace(go.Scatter(
                x=theoretical_quantiles,
                y=returns_sorted,
                mode='markers',
                name='Q-Q Plot'
            ))
            fig_qq.add_trace(go.Scatter(
                x=[-0.1, 0.1],
                y=[-0.1, 0.1],
                mode='lines',
                name='Normal',
                line=dict(color='red', dash='dash')
            ))
            fig_qq.update_layout(
                title='Q-Q Plot (Normality Test)',
                xaxis_title='Theoretical Quantiles',
                yaxis_title='Sample Quantiles',
                height=400
            )
            st.plotly_chart(fig_qq, use_container_width=True)
        
        # Export results
        st.markdown("### 💾 Export Results")
        
        if st.button("📥 Download Backtest Results", key="download_results_btn"):
            csv = results.to_csv()
            st.download_button(
                label="Download CSV",
                data=csv,
                file_name="stokasport_backtest_results.csv",
                mime="text/csv"
            )

st.markdown("---")
st.markdown("""
<div style='text-align: center'>
    <p><strong>STOKASPORT</strong> - AI-Powered Portfolio Optimization System</p>
    <p>Developed for Graduation Project | 2025</p>
</div>
""", unsafe_allow_html=True)