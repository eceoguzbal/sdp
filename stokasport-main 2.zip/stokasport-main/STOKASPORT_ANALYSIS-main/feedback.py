import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from sklearn.metrics import mean_absolute_error, mean_squared_error

def show_comparison_and_feedback(actual_values, forecast_values, dates=None):
    st.header("📊 Model Karşılaştırma ve Performans Analizi")

    # Eğer tarih yoksa indeks oluştur
    if dates is None:
        dates = list(range(len(actual_values)))

    # 1. Metriklerin Hesaplanması (Gerçek Matematiksel Verilerle)
    mae = mean_absolute_error(actual_values, forecast_values)
    rmse = np.sqrt(mean_squared_error(actual_values, forecast_values))
    mape = np.mean(np.abs((np.array(actual_values) - np.array(forecast_values)) / np.array(actual_values))) * 100

    # Metrikleri yan yana göster
    col1, col2, col3 = st.columns(3)
    col1.metric("MAE (Ort. Hata)", f"{mae:.4f}")
    col2.metric("RMSE (Sapma)", f"{rmse:.4f}")
    col3.metric("MAPE (Hata %)", f"%{mape:.2f}")

    # 2. Grafiksel Karşılaştırma
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=dates, y=actual_values, name='Gerçek Fiyat', line=dict(color='#1f77b4', width=3)))
    fig.add_trace(go.Scatter(x=dates, y=forecast_values, name='Model Tahmini', line=dict(color='#ff7f0e', dash='dash')))
    
    fig.update_layout(
        title="Gerçek vs Tahmin Edilen Değerler",
        xaxis_title="Tarih",
        yaxis_title="Fiyat",
        hovermode="x unified"
    )
    st.plotly_chart(fig, use_container_width=True)
    

    # 3. Kullanıcı Geri Bildirim Formu (Modeli Eğitmek İçin Veri Toplar)
    st.divider()
    st.subheader("📝 Modeli Değerlendir")
    
    with st.form("feedback_form"):
        rating = st.select_slider("Tahmin kalitesini puanlayın:", options=[1, 2, 3, 4, 5])
        comment = st.text_area("Gözlemleriniz (Opsiyonel):")
        submitted = st.form_submit_button("Geri Bildirimi Kaydet")
        
        if submitted:
            # Geri bildirimi CSV'ye kaydet (Daha sonra model retraining için kullanılacak)
            new_data = pd.DataFrame([[pd.Timestamp.now(), rating, mae, comment]], 
                                    columns=['timestamp', 'rating', 'mae', 'comment'])
            new_data.to_csv('user_feedback.csv', mode='a', header=False, index=False)
            st.success("Geri bildiriminiz kaydedildi. Modelin bir sonraki eğitiminde bu hata payı dikkate alınacak.")

