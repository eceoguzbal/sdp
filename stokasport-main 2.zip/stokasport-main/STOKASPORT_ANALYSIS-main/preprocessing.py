import numpy as np
import pandas as pd
import json
from sklearn.preprocessing import MinMaxScaler
import os

def load_any_data(path):
    """JSON veya CSV dosyasını okur, tarihleri düzenler ve temizler."""
    ext = os.path.splitext(path)[1].lower()

    if ext == ".json":
        with open(path, "r") as f:
            data = json.load(f)
        df = pd.DataFrame(data["archive"])
    elif ext == ".csv":
        df = pd.read_csv(path)
    else:
        raise ValueError("Desteklenmeyen dosya formatı.")

    # 1. Tarih Sütununu Düzenleme
    for col in ['update_date', 'date', 'Timestamp']:
        if col in df.columns:
            # Eğer Unix timestamp ise çevir, değilse normal çevir
            if df[col].dtype == 'int64' or df[col].dtype == 'float64':
                df[col] = pd.to_datetime(df[col], unit='s')
            else:
                df[col] = pd.to_datetime(df[col])
            df.set_index(col, inplace=True)
            break
    
    # 2. Fiyat Sütununu Belirleme (Esnek Yapı)
    target_col = None
    possible_cols = ['close_try', 'close_usd', 'close', 'price']
    for col in possible_cols:
        if col in df.columns:
            target_col = col
            break
    
    if target_col is None:
        raise ValueError("Fiyat sütunu bulunamadı!")

    # Sadece gerekli verileri temizleyerek al
    df = df[[target_col]].copy()
    df.rename(columns={target_col: 'close'}, inplace=True)
    df = df.sort_index().dropna()
    
    return df

def add_technical_indicators(df):
    """Veriye RSI ve SMA gibi temel teknik göstergeleri ekler."""
    # Hareketli Ortalamalar (SMA)
    df['SMA_20'] = df['close'].rolling(window=20).mean()
    df['SMA_50'] = df['close'].rolling(window=50).mean()
    
    # RSI (Göreceli Güç Endeksi)
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss
    df['RSI'] = 100 - (100 / (1 + rs))
    
    # Volatilite (Standart Sapma)
    df['Volatility'] = df['close'].rolling(window=20).std()
    
    return df.dropna()

def scale_data(df):
    """Tüm sütunları 0-1 arasına ölçekler."""
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled_data = scaler.fit_transform(df)
    return scaled_data, scaler