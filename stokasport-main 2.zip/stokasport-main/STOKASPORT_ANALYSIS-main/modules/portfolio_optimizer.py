

import numpy as np
import pandas as pd
import cvxpy as cp
from scipy.optimize import minimize
import config

# modules/portfolio_optimizer.py içinde:
# optimize_sharpe ismini optimize_sharpe_ratio yapın veya altına şunu ekleyin:
def optimize_sharpe_ratio(self, mu, cov, min_weight=0.0, max_weight=0.15):
    return self.optimize_sharpe(mu, cov, min_w=min_weight, max_w=max_weight)

class PortfolioOptimizer:

    def __init__(self, risk_free_rate=config.RISK_FREE_RATE):
        self.risk_free_rate = risk_free_rate
        self.optimal_weights = None
        self.frontier_df = None

    # -------------------------------------------------------
    # METRICS & STATISTICS
    # -------------------------------------------------------
    def calculate_portfolio_metrics(self, weights, mu, cov):
        """Arayüzün (app.py) beklediği metrik hesaplama fonksiyonu"""
        port_return = np.dot(weights, mu)
        port_vol = np.sqrt(weights.T @ cov @ weights)
        sharpe = (port_return - self.risk_free_rate) / port_vol if port_vol > 0 else 0
        return port_return, port_vol, sharpe

    def portfolio_statistics(self, weights, mu, cov):
        """Dahili kullanım için istatistikler"""
        return self.calculate_portfolio_metrics(weights, mu, cov)

    # -------------------------------------------------------
    # SHARPE RATIO OPTIMIZATION (Fixing the Method Name)
    # -------------------------------------------------------
    def optimize_sharpe_ratio(self, mu, cov, min_weight=0.0, max_weight=0.15):
        """app.py tarafından çağrılan Sharpe optimizasyon metodu"""
        n = len(mu)

        def neg_sharpe(w):
            return -self.portfolio_statistics(w, mu, cov)[2]

        constraints = [{'type': 'eq', 'fun': lambda w: np.sum(w) - 1}]
        bounds = [(min_weight, max_weight)] * n
        x0 = np.ones(n) / n

        res = minimize(neg_sharpe, x0, bounds=bounds, constraints=constraints, method='SLSQP')

        if not res.success:
            # Optimizasyon başarısız olursa eşit ağırlıklı portföy döndür
            self.optimal_weights = np.ones(n) / n
        else:
            self.optimal_weights = res.x
            
        return self.optimal_weights

    # -------------------------------------------------------
    # RISK TOLERANCE ADJUSTMENT
    # -------------------------------------------------------
    def apply_risk_tolerance(self, weights, risk_level='Medium'):
        """app.py'nin beklediği risk tolerans filtresi"""
        # Burada seçilen risk seviyesine göre ağırlıklarda ince ayar yapılabilir.
        # Şimdilik ana ağırlıkları koruyup döndürüyoruz.
        return weights

    # -------------------------------------------------------
    # MEAN-VARIANCE OPTIMIZATION
    # -------------------------------------------------------
    def optimize_mean_variance(self, mu, cov, target_return):
        n = len(mu)
        w = cp.Variable(n)

        risk = cp.quad_form(w, cov)
        constraints = [
            cp.sum(w) == 1,
            w >= 0,
            mu @ w >= target_return
        ]

        prob = cp.Problem(cp.Minimize(risk), constraints)
        prob.solve()

        self.optimal_weights = w.value
        return w.value

    # -------------------------------------------------------
    # EFFICIENT FRONTIER
    # -------------------------------------------------------
    def generate_efficient_frontier(self, mu, cov, n_points=50):
        """app.py'nin beklediği isim: generate_efficient_frontier"""
        returns = np.linspace(mu.min(), mu.max(), n_points)
        frontier = []

        for r in returns:
            try:
                w = self.optimize_mean_variance(mu, cov, r)
                if w is not None:
                    ret, vol, sharpe = self.portfolio_statistics(w, mu, cov)
                    # Yıllıklandırma (Opsiyonel, config'e göre)
                    ann_ret = ret * 252 
                    ann_vol = vol * np.sqrt(252)
                    frontier.append([ann_ret, ann_vol, sharpe])
            except:
                continue

        self.frontier_df = pd.DataFrame(
            frontier, columns=["Return", "Volatility", "Sharpe"]
        )
        return self.frontier_df