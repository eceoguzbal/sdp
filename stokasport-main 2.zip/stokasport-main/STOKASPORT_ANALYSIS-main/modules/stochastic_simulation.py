"""
Monte Carlo simulation using Geometric Brownian Motion
"""

import numpy as np
import pandas as pd
from scipy import stats
import config

class MonteCarloSimulator:
    def __init__(self, n_simulations: int = config.MC_SIMULATIONS,
                 time_horizon: int = config.MC_TIME_HORIZON):
        """
        Initialize Monte Carlo simulator
        
        Args:
            n_simulations: Number of simulation paths
            time_horizon: Number of time steps to simulate
        """
        self.n_simulations = n_simulations
        self.time_horizon = time_horizon
        self.simulated_paths = None
        
    def estimate_parameters(self, returns: pd.Series) -> tuple:
        """
        Estimate drift and volatility from historical returns
        
        Args:
            returns: Historical returns series
            
        Returns:
            (drift, volatility)
        """
        # Calculate daily mean return (drift)
        mu = returns.mean()
        
        # Calculate daily volatility
        sigma = returns.std()
        
        return mu, sigma
    
    def simulate_gbm(self, S0: float, mu: float, sigma: float) -> np.ndarray:
        """
        Simulate price paths using Geometric Brownian Motion
        
        S(t) = S0 * exp((mu - 0.5*sigma^2)*t + sigma*W(t))
        
        Args:
            S0: Initial price
            mu: Drift (mean return)
            sigma: Volatility (std of returns)
            
        Returns:
            Array of shape (n_simulations, time_horizon)
        """
        dt = 1  # daily time step
        
        # Generate random normal variables
        Z = np.random.standard_normal((self.n_simulations, self.time_horizon))
        
        # Initialize price paths
        paths = np.zeros((self.n_simulations, self.time_horizon + 1))
        paths[:, 0] = S0
        
        # Simulate paths
        for t in range(1, self.time_horizon + 1):
            paths[:, t] = paths[:, t-1] * np.exp(
                (mu - 0.5 * sigma**2) * dt + sigma * np.sqrt(dt) * Z[:, t-1]
            )
        
        self.simulated_paths = paths
        return paths
    
    def simulate_portfolio(self, prices: pd.DataFrame, 
                          weights: np.ndarray,
                          returns: pd.DataFrame = None) -> np.ndarray:
        """
        Simulate portfolio value using individual asset simulations
        
        Args:
            prices: DataFrame of current prices (last row used as S0)
            weights: Portfolio weights (must sum to 1)
            returns: Historical returns DataFrame
            
        Returns:
            Array of portfolio value paths (n_simulations, time_horizon+1)
        """
        if returns is None:
            returns = prices.pct_change().dropna()
        
        n_assets = len(weights)
        portfolio_paths = np.zeros((self.n_simulations, self.time_horizon + 1))
        portfolio_paths[:, 0] = 1.0  # Start with normalized portfolio value of 1
        
        # Simulate each asset
        asset_paths = {}
        for i, asset in enumerate(prices.columns):
            S0 = prices[asset].iloc[-1]
            mu, sigma = self.estimate_parameters(returns[asset])
            
            # Simulate this asset
            paths = self.simulate_gbm(S0, mu, sigma)
            asset_paths[asset] = paths
        
        # Combine into portfolio
        for i, asset in enumerate(prices.columns):
            # Normalize paths to relative performance
            normalized_paths = asset_paths[asset] / asset_paths[asset][:, 0:1]
            portfolio_paths += weights[i] * normalized_paths
        
        return portfolio_paths
    
    def calculate_var(self, portfolio_paths: np.ndarray, 
                     confidence_level: float = 0.95) -> float:
        """
        Calculate Value at Risk (VaR)
        
        Args:
            portfolio_paths: Simulated portfolio value paths
            confidence_level: Confidence level (e.g., 0.95 for 95% VaR)
            
        Returns:
            VaR value
        """
        # Get final portfolio values
        final_values = portfolio_paths[:, -1]
        
        # Calculate returns
        returns = (final_values - 1.0)
        
        # VaR is the percentile of the loss distribution
        var = np.percentile(returns, (1 - confidence_level) * 100)
        
        return var
    
    def calculate_cvar(self, portfolio_paths: np.ndarray,
                      confidence_level: float = 0.95) -> float:
        """
        Calculate Conditional Value at Risk (CVaR) / Expected Shortfall
        
        Args:
            portfolio_paths: Simulated portfolio value paths
            confidence_level: Confidence level
            
        Returns:
            CVaR value
        """
        # Get final portfolio values
        final_values = portfolio_paths[:, -1]
        
        # Calculate returns
        returns = (final_values - 1.0)
        
        # Calculate VaR threshold
        var_threshold = np.percentile(returns, (1 - confidence_level) * 100)
        
        # CVaR is the expected value of returns below VaR
        cvar = returns[returns <= var_threshold].mean()
        
        return cvar
    
    def get_simulation_statistics(self, paths: np.ndarray) -> dict:
        """
        Calculate statistics from simulated paths
        
        Args:
            paths: Simulated paths
            
        Returns:
            Dictionary of statistics
        """
        final_values = paths[:, -1]
        
        stats_dict = {
            'Mean_Final_Value': final_values.mean(),
            'Median_Final_Value': np.median(final_values),
            'Std_Final_Value': final_values.std(),
            'Min_Final_Value': final_values.min(),
            'Max_Final_Value': final_values.max(),
            'Percentile_5': np.percentile(final_values, 5),
            'Percentile_25': np.percentile(final_values, 25),
            'Percentile_75': np.percentile(final_values, 75),
            'Percentile_95': np.percentile(final_values, 95),
            'VaR_95': self.calculate_var(paths, 0.95),
            'CVaR_95': self.calculate_cvar(paths, 0.95)
        }
        
        return stats_dict
    
    def get_confidence_intervals(self, paths: np.ndarray, 
                                 confidence_level: float = 0.95) -> tuple:
        """
        Calculate confidence intervals for each time step
        
        Args:
            paths: Simulated paths
            confidence_level: Confidence level
            
        Returns:
            (lower_bound, median, upper_bound) arrays
        """
        alpha = (1 - confidence_level) / 2
        lower = np.percentile(paths, alpha * 100, axis=0)
        median = np.percentile(paths, 50, axis=0)
        upper = np.percentile(paths, (1 - alpha) * 100, axis=0)
        
        return lower, median, upper