"""
Machine Learning models: XGBoost
"""

import pandas as pd
import numpy as np
from xgboost import XGBRegressor
from sklearn.preprocessing import StandardScaler
import config


class MLForecaster:
    def __init__(self, model_type='xgboost'):
        self.model_type = model_type
        self.model = None
        self.scaler = StandardScaler()
        self.feature_names = None

        if model_type == 'xgboost':
            self.model = XGBRegressor(**config.XGBOOST_PARAMS)
        else:
            raise ValueError("Only 'xgboost' model is supported.")

    def prepare_data(self, data: pd.Series, horizon: int = 1):
        """Prepare features and target for ML models"""
        from modules.data_loader import DataLoader

        loader = DataLoader()
        features = loader.create_features(data)

        # Create target (future value)
        target = data.shift(-horizon)

        # Align
        aligned = pd.concat([features, target.rename("target")], axis=1).dropna()

        X = aligned.drop("target", axis=1)
        y = aligned["target"]

        self.feature_names = X.columns.tolist()
        return X, y

    def fit(self, X: pd.DataFrame, y: pd.Series):
        X_scaled = self.scaler.fit_transform(X)
        self.model.fit(X_scaled, y)
        return self

    def predict(self, X: pd.DataFrame):
        X_scaled = self.scaler.transform(X)
        return self.model.predict(X_scaled)

    def get_feature_importance(self):
        if self.model is None:
            return None

        return pd.DataFrame({
            "feature": self.feature_names,
            "importance": self.model.feature_importances_
        }).sort_values("importance", ascending=False)


class MLPipeline:
    def __init__(self):
        self.models = {}
        self.predictions = {}

    def fit_models(self, data: pd.Series, asset_name: str, horizon: int = 1):
        ml = MLForecaster(model_type="xgboost")
        X, y = ml.prepare_data(data, horizon=horizon)

        split = int(len(X) * 0.8)
        X_train, X_val = X.iloc[:split], X.iloc[split:]
        y_train, y_val = y.iloc[:split], y.iloc[split:]

        ml.fit(X_train, y_train)
        self.models[f"{asset_name}_XGBoost"] = ml

        return self, X_val, y_val

    def predict_all(self, X: pd.DataFrame):
        preds = {}
        for name, model in self.models.items():
            preds[name] = model.predict(X)
        self.predictions = preds
        return preds


def create_ml_forecasts(data: pd.DataFrame, asset_names: list, horizon: int = 1):
    all_models = {}
    all_predictions = {}

    for asset in asset_names:
        print(f"Training ML model for {asset}...")

        pipeline = MLPipeline()
        pipeline, X_val, y_val = pipeline.fit_models(
            data[asset], asset, horizon
        )

        preds = pipeline.predict_all(X_val)

        all_models[asset] = pipeline
        all_predictions[asset] = preds

    return all_models, all_predictions
