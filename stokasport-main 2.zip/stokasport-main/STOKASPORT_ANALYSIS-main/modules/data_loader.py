"""
Data loading and preprocessing module - Integrated Fix Version
"""

import json
import os
import pandas as pd
import numpy as np
from typing import Dict, List, Tuple

# Try to import config, fallback to defaults if not found
try:
    import config
except ImportError:
    class MockConfig:
        DATA_PATH = 'data'
        TRAIN_TEST_SPLIT = 0.8
        LAG_FEATURES = [1, 2, 3, 5]
        ROLLING_WINDOWS = [5, 10, 20]
        TECHNICAL_INDICATORS = True
    config = MockConfig()

class DataLoader:
    def __init__(self, data_path: str = config.DATA_PATH):
        self.data_path = data_path
        self.asset_data = {}
        self.asset_names = []
        
    def load_all_assets(self) -> Dict[str, pd.DataFrame]:
        """Load all JSON files from data directory with error handling for truncated files"""
        if not os.path.exists(self.data_path):
            raise FileNotFoundError(f"Data directory not found: {self.data_path}")

        json_files = [f for f in os.listdir(self.data_path) if f.endswith('.json')]
        
        if len(json_files) == 0:
            raise FileNotFoundError(f"No JSON files found in {self.data_path}")
        
        for file in json_files:
            asset_name = file.replace('.json', '')
            file_path = os.path.join(self.data_path, file)
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                df = self._parse_json_data(data, file)
                
                if df is None or len(df) == 0:
                    continue
                
                self.asset_data[asset_name] = df
                self.asset_names.append(asset_name)
                
            except (json.JSONDecodeError, Exception):
                continue
        
        if len(self.asset_data) == 0:
            raise ValueError("No valid asset data could be loaded.")
        
        return self.asset_data
    
    def _parse_json_data(self, data: dict, filename: str) -> pd.DataFrame:
        """Improved parser supporting 'archive' format, Unix timestamps, and zero-filtering."""
        if isinstance(data, dict):
            if 'archive' in data and isinstance(data['archive'], list):
                data = data['archive']
            elif 'data' in data and isinstance(data['data'], list):
                data = data['data']

        if isinstance(data, list) and len(data) > 0:
            try:
                df = pd.DataFrame(data)
                
                date_col = next((col for col in ['update_date', 'date', 'Date', 'datetime', 'timestamp'] if col in df.columns), None)
                price_col = next((col for col in ['close', 'price', 'Price', 'Close', 'value'] if col in df.columns), None)
                
                if date_col and price_col:
                    if pd.api.types.is_numeric_dtype(df[date_col]):
                        df.index = pd.to_datetime(df[date_col], unit='s')
                    else:
                        df.index = pd.to_datetime(df[date_col])
                        
                    df = df[[price_col]].rename(columns={price_col: 'price'})
                    df['price'] = pd.to_numeric(df['price'], errors='coerce')
                    df = df[df['price'] > 0].dropna().sort_index()
                    return df
            except Exception:
                pass

        if isinstance(data, dict) and len(data) > 0:
            try:
                df = pd.DataFrame.from_dict(data, orient='index', columns=['price'])
                df.index = pd.to_datetime(df.index)
                df['price'] = pd.to_numeric(df['price'], errors='coerce')
                return df[df['price'] > 0].dropna().sort_index()
            except Exception:
                pass
        
        return None
    
    def get_combined_dataframe(self) -> pd.DataFrame:
        """Combine all assets into single DataFrame with assets as columns"""
        if not self.asset_data:
            self.load_all_assets()
        
        combined = pd.DataFrame()
        for asset_name, df in self.asset_data.items():
            combined[asset_name] = df['price']
        
        return combined.ffill().dropna()
    
    def calculate_returns(self, prices: pd.DataFrame, method='simple') -> pd.DataFrame:
        """Calculate returns from prices"""
        if method == 'simple':
            return prices.pct_change().dropna()
        elif method == 'log':
            return np.log(prices / prices.shift(1)).dropna()
        else:
            raise ValueError("method must be 'simple' or 'log'")
    
    def get_train_test_split(self, data: pd.DataFrame, 
                            split_ratio: float = config.TRAIN_TEST_SPLIT) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """Split data into train and test sets"""
        split_idx = int(len(data) * split_ratio)
        return data.iloc[:split_idx], data.iloc[split_idx:]
    
    def create_features(self, data: pd.Series, lags: List[int] = None, 
                       windows: List[int] = None) -> pd.DataFrame:
        """Create lag and rolling window features for ML models"""
        lags = lags or config.LAG_FEATURES
        windows = windows or config.ROLLING_WINDOWS
        
        features = pd.DataFrame(index=data.index)
        
        for lag in lags:
            features[f'lag_{lag}'] = data.shift(lag)
        
        for window in windows:
            features[f'rolling_mean_{window}'] = data.rolling(window=window).mean()
            features[f'rolling_std_{window}'] = data.rolling(window=window).std()
            features[f'rolling_min_{window}'] = data.rolling(window=window).min()
            features[f'rolling_max_{window}'] = data.rolling(window=window).max()
        
        if config.TECHNICAL_INDICATORS:
            features['roc_5'] = data.pct_change(periods=5)
            features['momentum_5'] = data - data.shift(5)
            delta = data.diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
            rs = gain / loss
            features['rsi'] = 100 - (100 / (1 + rs))
        
        return features.dropna()

    def get_data_summary(self) -> pd.DataFrame:
        """Varlıkların özet istatistiklerini temiz bir formatta döndürür."""
        if not self.asset_data:
            self.load_all_assets()
        
        summary = []
        for asset_name, df in self.asset_data.items():
            summary.append({
                'Asset': asset_name,
                'Start Date': df.index.min().date() if not df.empty else None,
                'End Date': df.index.max().date() if not df.empty else None,
                'Observations': len(df),
                'Mean Price': round(df['price'].mean(), 4) if not df.empty else 0,
                'Std Price': round(df['price'].std(), 4) if not df.empty else 0
            })
        return pd.DataFrame(summary)