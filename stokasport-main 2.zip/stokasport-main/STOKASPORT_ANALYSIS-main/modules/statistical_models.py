"""
Statistical forecasting models: ARIMA, SARIMA, VAR
"""

import pandas as pd
import numpy as np
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.vector_ar.var_model import VAR
from pmdarima import auto_arima

import warnings
warnings.filterwarnings('ignore')
try:
    import config
except ImportError:
    # Fallback if config is missing during direct script execution
    class config:
        ARIMA_MAX_P, ARIMA_MAX_Q, ARIMA_MAX_D = 5, 5, 2
        SARIMA_SEASONAL_PERIOD = 5

class ARIMAModel:
    def __init__(self, order=None, auto=True):
        self.order = order
        self.auto = auto
        self.model = None
        self.fitted_model = None
        
    def fit(self, data: pd.Series):
        if self.auto:
            self.model = auto_arima(
                data,
                start_p=0, start_q=0,
                max_p=config.ARIMA_MAX_P,
                max_q=config.ARIMA_MAX_Q,
                max_d=config.ARIMA_MAX_D,
                seasonal=False,
                stepwise=True,
                suppress_warnings=True,
                error_action='ignore',
                trace=False
            )
            self.order = self.model.order
        else:
            self.model = ARIMA(data, order=self.order)
            self.fitted_model = self.model.fit()
        return self
    
    def predict(self, steps: int = 1) -> np.ndarray:
        if self.auto:
            forecast = self.model.predict(n_periods=steps)
        else:
            forecast = self.fitted_model.forecast(steps=steps)
        return forecast
    
    def get_order(self):
        return self.order


class SARIMAModel:
    def __init__(self, order=None, seasonal_order=None, auto=True):
        self.order = order
        self.seasonal_order = seasonal_order
        self.auto = auto
        self.model = None
        
    def fit(self, data: pd.Series):
        if self.auto:
            self.model = auto_arima(
                data,
                start_p=0, start_q=0,
                max_p=config.ARIMA_MAX_P,
                max_q=config.ARIMA_MAX_Q,
                max_d=config.ARIMA_MAX_D,
                seasonal=True,
                m=config.SARIMA_SEASONAL_PERIOD,
                start_P=0, start_Q=0,
                max_P=2, max_Q=2, max_D=1,
                stepwise=True,
                suppress_warnings=True,
                error_action='ignore',
                trace=False
            )
            self.order = self.model.order
            self.seasonal_order = self.model.seasonal_order
        else:
            self.model = SARIMAX(
                data,
                order=self.order,
                seasonal_order=self.seasonal_order
            ).fit(disp=False)
        return self
    
    def predict(self, steps: int = 1) -> np.ndarray:
        if self.auto:
            forecast = self.model.predict(n_periods=steps)
        else:
            forecast = self.model.forecast(steps=steps)
        return forecast

    # EKSİK OLAN METOT EKLENDİ: get_order()
    def get_order(self):
        """Hata veren eksik metot eklendi"""
        return self.order

    def get_seasonal_order(self):
        """Seasonal bilgisi için yardımcı metot"""
        return self.seasonal_order


class VARModel:
    def __init__(self, maxlags=10):
        self.maxlags = maxlags
        self.model = None
        self.fitted_model = None
        self.selected_lag = None
        
    def fit(self, data: pd.DataFrame):
        self.model = VAR(data)
        try:
            lag_order_results = self.model.select_order(maxlags=self.maxlags)
            self.selected_lag = lag_order_results.aic
        except:
            self.selected_lag = 1
        self.fitted_model = self.model.fit(self.selected_lag)
        return self
    
    def predict(self, steps: int = 1) -> pd.DataFrame:
        forecast = self.fitted_model.forecast(
            self.fitted_model.y[-self.selected_lag:],
            steps=steps
        )
        return pd.DataFrame(forecast, columns=self.fitted_model.names)
    
    def get_lag_order(self):
        return self.selected_lag


class StatisticalForecaster:
    def __init__(self):
        self.models = {}
        self.predictions = {}
        
    def fit_all_models(self, data: pd.DataFrame, asset_name: str):
        series = data[asset_name]
        arima = ARIMAModel(auto=True)
        arima.fit(series)
        self.models[f'{asset_name}_ARIMA'] = arima
        
        sarima = SARIMAModel(auto=True)
        sarima.fit(series)
        self.models[f'{asset_name}_SARIMA'] = sarima
        return self
    
    def fit_var_model(self, data: pd.DataFrame, asset_list: list = None):
        var_data = data if asset_list is None else data[asset_list]
        var_model = VARModel(maxlags=10)
        var_model.fit(var_data)
        self.models['VAR'] = var_model
        return self
    
    def predict_all(self, steps: int = 1):
        predictions = {}
        for model_name, model in self.models.items():
            try:
                pred = model.predict(steps=steps)
                predictions[model_name] = pred
            except Exception as e:
                predictions[model_name] = None
        self.predictions = predictions
        return predictions
    
    def get_model_summary(self):
        """GÜNCELLENDİ: Hata almamak için güvenli erişim sağlandı"""
        summary = []
        for name, model in self.models.items():
            # hasattr kontrolü ile güvenli hale getirildi
            if 'ARIMA' in name or 'SARIMA' in name:
                order = getattr(model, 'get_order', lambda: "N/A")() #
                row = {
                    'Model': name,
                    'Type': 'ARIMA' if 'SARIMA' not in name else 'SARIMA',
                    'Order': order
                }
                if 'SARIMA' in name:
                    row['Seasonal Order'] = getattr(model, 'get_seasonal_order', lambda: "N/A")()
                summary.append(row)
            elif name == 'VAR':
                summary.append({
                    'Model': name,
                    'Type': 'VAR',
                    'Lag Order': model.get_lag_order()
                })
        return pd.DataFrame(summary)