"""
Backtesting module with walk-forward validation
"""

import numpy as np
import pandas as pd
from typing import Callable, Dict
import config

class Backtester:
    def __init__(self, window_size: int = config.WALK_FORWARD_WINDOW,
                 rebalance_freq: int = config.REBALANCING_FREQ):
        """
        Initialize backtester
        
        Args:
            window_size: Size of rolling training window (in days)
            rebalance_freq: Rebalancing frequency (in days)
        """
        self.window_size = window_size
        self.rebalance_freq = rebalance_freq
        self.results = None
        self.portfolio_values = None
        
    def walk_forward_validation(self, data: pd.DataFrame,
                                optimization_func: Callable,
                                prediction_func: Callable = None) -> pd.DataFrame:
        """
        Perform walk-forward backtesting
        """
        returns = data.pct_change().dropna()
        n_assets = len(data.columns)
        
        portfolio_returns = []
        weights_history = []
        dates = []
        
        start_idx = self.window_size
        
        for i in range(start_idx, len(returns), self.rebalance_freq):
            # Training window
            train_returns = returns.iloc[i - self.window_size:i]
            
            # Test period
            end_idx = min(i + self.rebalance_freq, len(returns))
            test_returns = returns.iloc[i:end_idx]
            
            if len(test_returns) == 0:
                break
            
            expected_returns = train_returns.mean().values
            cov_matrix = train_returns.cov().values
            
            try:
                weights = optimization_func(expected_returns, cov_matrix)
            except:
                weights = np.array([1.0 / n_assets] * n_assets)
            
            port_ret = (test_returns.values @ weights)
            
            portfolio_returns.extend(port_ret)
            weights_history.append({
                'date': returns.index[i],
                'weights': weights,
                'assets': data.columns.tolist()
            })
            dates.extend(test_returns.index)
        
        self.results = pd.DataFrame({
            'Date': dates,
            'Portfolio_Return': portfolio_returns
        })
        self.results.set_index('Date', inplace=True)
        self.results['Cumulative_Return'] = (1 + self.results['Portfolio_Return']).cumprod()
        
        return self.results, weights_history

    def calculate_performance_metrics(self, returns: pd.Series = None) -> Dict:
        """
        Calculate portfolio performance metrics with safety checks to avoid ZeroDivisionError
        """
        if returns is None:
            if self.results is None or self.results.empty:
                return {
                    'Cumulative_Return': 0, 'Annualized_Return': 0, 
                    'Annualized_Volatility': 0, 'Sharpe_Ratio': 0, 
                    'Max_Drawdown': 0, 'Win_Rate': 0, 'Total_Days': 0
                }
            returns = self.results['Portfolio_Return']
        
        n_days = len(returns)
        if n_days == 0:
            return {'Cumulative_Return': 0, 'Sharpe_Ratio': 0, 'Total_Days': 0}

        # Cumulative return
        cumulative_return = (1 + returns).prod() - 1
        
        # Annualized return calculation with safety check
        n_years = n_days / config.TRADING_DAYS_PER_YEAR
        if n_years <= 0: 
            n_years = 1 / 252 
        
        annualized_return = (1 + cumulative_return) ** (1 / n_years) - 1
        
        # Volatility
        daily_vol = returns.std()
        annualized_vol = daily_vol * np.sqrt(config.TRADING_DAYS_PER_YEAR)
        
        # Sharpe ratio
        excess_return = annualized_return - config.RISK_FREE_RATE
        sharpe_ratio = excess_return / annualized_vol if annualized_vol > 0 else 0
        
        # Maximum drawdown
        cumulative = (1 + returns).cumprod()
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        max_drawdown = drawdown.min()
        
        # Win rate
        win_rate = (returns > 0).sum() / n_days
        
        return {
            'Cumulative_Return': cumulative_return,
            'Annualized_Return': annualized_return,
            'Annualized_Volatility': annualized_vol,
            'Sharpe_Ratio': sharpe_ratio,
            'Max_Drawdown': max_drawdown,
            'Win_Rate': win_rate,
            'Total_Days': n_days
        }

    def calculate_rolling_metrics(self, window: int = 60) -> pd.DataFrame:
        """Calculate rolling performance metrics"""
        if self.results is None or self.results.empty:
            raise ValueError("No backtest results available")
        
        returns = self.results['Portfolio_Return']
        rolling_metrics = pd.DataFrame(index=returns.index)
        
        rolling_metrics['Rolling_Return'] = returns.rolling(window).mean() * config.TRADING_DAYS_PER_YEAR
        rolling_metrics['Rolling_Volatility'] = returns.rolling(window).std() * np.sqrt(config.TRADING_DAYS_PER_YEAR)
        
        rolling_metrics['Rolling_Sharpe'] = (
            (rolling_metrics['Rolling_Return'] - config.RISK_FREE_RATE) / 
            rolling_metrics['Rolling_Volatility']
        ).replace([np.inf, -np.inf], 0)
        
        return rolling_metrics.dropna()

    def get_drawdown_series(self) -> pd.Series:
        """Get drawdown time series"""
        if self.results is None or self.results.empty:
            raise ValueError("No backtest results available")
        
        returns = self.results['Portfolio_Return']
        cumulative = (1 + returns).cumprod()
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        return drawdown

    def compare_strategies(self, strategies_returns: Dict[str, pd.Series]) -> pd.DataFrame:
        """Compare multiple portfolio strategies"""
        comparison = []
        for name, returns in strategies_returns.items():
            if returns is not None and not returns.empty:
                metrics = self.calculate_performance_metrics(returns)
                metrics['Strategy'] = name
                comparison.append(metrics)
        
        if not comparison:
            return pd.DataFrame()
            
        return pd.DataFrame(comparison).set_index('Strategy')