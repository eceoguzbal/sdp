"""
Ensemble methods for combining predictions from multiple models
"""

import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error
from typing import Dict, List

class EnsembleForecaster:
    def __init__(self, method='performance_weighted'):
        """
        Initialize ensemble forecaster
        
        Args:
            method: 'equal_weight', 'performance_weighted', or 'inverse_error'
        """
        self.method = method
        self.weights = {}
        self.model_performance = {}
        
    def calculate_metrics(self, y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
        """Calculate error metrics"""
        rmse = np.sqrt(mean_squared_error(y_true, y_pred))
        mae = mean_absolute_error(y_true, y_pred)
        mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
        
        # Directional accuracy
        direction_true = np.sign(np.diff(y_true))
        direction_pred = np.sign(np.diff(y_pred))
        directional_accuracy = np.mean(direction_true == direction_pred) * 100
        
        return {
            'RMSE': rmse,
            'MAE': mae,
            'MAPE': mape,
            'Directional_Accuracy': directional_accuracy
        }
    
    def evaluate_models(self, predictions: Dict[str, np.ndarray], 
                       y_true: np.ndarray) -> pd.DataFrame:
        """
        Evaluate all model predictions against true values
        
        Args:
            predictions: Dictionary of model_name -> predictions
            y_true: True values
            
        Returns:
            DataFrame with performance metrics for each model
        """
        results = []
        
        for model_name, y_pred in predictions.items():
            if y_pred is not None and len(y_pred) == len(y_true):
                metrics = self.calculate_metrics(y_true, y_pred)
                metrics['Model'] = model_name
                results.append(metrics)
                self.model_performance[model_name] = metrics
        
        return pd.DataFrame(results)
    
    def calculate_weights(self, performance_df: pd.DataFrame, 
                         metric: str = 'RMSE') -> Dict[str, float]:
        """
        Calculate ensemble weights based on model performance
        
        Args:
            performance_df: DataFrame with model performance metrics
            metric: Metric to use for weighting (RMSE, MAE, etc.)
            
        Returns:
            Dictionary of model weights
        """
        if self.method == 'equal_weight':
            n_models = len(performance_df)
            weights = {row['Model']: 1.0 / n_models 
                      for _, row in performance_df.iterrows()}
        
        elif self.method == 'performance_weighted' or self.method == 'inverse_error':
            # Use inverse of error as weight
            errors = performance_df[metric].values
            
            # Avoid division by zero
            errors = np.where(errors == 0, 1e-10, errors)
            
            # Inverse error weighting
            inverse_errors = 1.0 / errors
            
            # Normalize to sum to 1
            weights_array = inverse_errors / inverse_errors.sum()
            
            weights = {row['Model']: weight 
                      for (_, row), weight in zip(performance_df.iterrows(), weights_array)}
        
        else:
            raise ValueError(f"Unknown weighting method: {self.method}")
        
        self.weights = weights
        return weights
    
    def combine_predictions(self, predictions: Dict[str, np.ndarray], 
                          weights: Dict[str, float] = None) -> np.ndarray:
        """
        Combine predictions using calculated or provided weights
        
        Args:
            predictions: Dictionary of model_name -> predictions
            weights: Optional weights dictionary (uses self.weights if None)
            
        Returns:
            Weighted ensemble prediction
        """
        if weights is None:
            weights = self.weights
        
        if not weights:
            raise ValueError("No weights calculated. Run calculate_weights first.")
        
        # Filter predictions that exist
        valid_predictions = {k: v for k, v in predictions.items() 
                           if v is not None and k in weights}
        
        if not valid_predictions:
            raise ValueError("No valid predictions to combine")
        
        # Get prediction length from first valid prediction
        pred_length = len(next(iter(valid_predictions.values())))
        
        # Initialize ensemble prediction
        ensemble_pred = np.zeros(pred_length)
        
        # Weighted sum
        total_weight = 0
        for model_name, pred in valid_predictions.items():
            weight = weights[model_name]
            ensemble_pred += weight * pred
            total_weight += weight
        
        # Renormalize if weights don't sum to 1
        if total_weight > 0:
            ensemble_pred /= total_weight
        
        return ensemble_pred
    
    def get_weights_df(self) -> pd.DataFrame:
        """Get weights as a DataFrame"""
        if not self.weights:
            return pd.DataFrame()
        
        return pd.DataFrame([
            {'Model': k, 'Weight': v} 
            for k, v in self.weights.items()
        ]).sort_values('Weight', ascending=False)


def create_ensemble_forecast(predictions: Dict[str, np.ndarray],
                            y_true: np.ndarray,
                            method: str = 'performance_weighted',
                            metric: str = 'RMSE') -> tuple:
    """
    Create ensemble forecast from multiple model predictions
    
    Args:
        predictions: Dictionary of model predictions
        y_true: True values for validation
        method: Ensemble method
        metric: Metric to use for weighting
        
    Returns:
        (ensemble_prediction, weights_df, performance_df)
    """
    ensemble = EnsembleForecaster(method=method)
    
    # Evaluate all models
    performance_df = ensemble.evaluate_models(predictions, y_true)
    
    # Calculate weights
    weights = ensemble.calculate_weights(performance_df, metric=metric)
    
    # Create ensemble prediction
    ensemble_pred = ensemble.combine_predictions(predictions, weights)
    
    # Get weights DataFrame
    weights_df = ensemble.get_weights_df()
    
    return ensemble_pred, weights_df, performance_df