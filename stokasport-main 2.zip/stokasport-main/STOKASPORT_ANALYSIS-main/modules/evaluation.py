"""
Evaluation metrics for prediction models
"""

import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from typing import Dict

class ModelEvaluator:
    def __init__(self):
        self.results = {}
        
    def calculate_rmse(self, y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Root Mean Squared Error"""
        return np.sqrt(mean_squared_error(y_true, y_pred))
    
    def calculate_mae(self, y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Mean Absolute Error"""
        return mean_absolute_error(y_true, y_pred)
    
    def calculate_mape(self, y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Mean Absolute Percentage Error"""
        # Avoid division by zero
        mask = y_true != 0
        if mask.sum() == 0:
            return np.inf
        return np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100
    
    def calculate_directional_accuracy(self, y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """
        Directional accuracy - percentage of correct direction predictions
        """
        if len(y_true) <= 1:
            return 0.0
        
        # Calculate actual direction (up/down)
        true_direction = np.sign(np.diff(y_true))
        pred_direction = np.sign(np.diff(y_pred))
        
        # Calculate accuracy
        accuracy = np.mean(true_direction == pred_direction) * 100
        return accuracy
    
    def calculate_r2(self, y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """R-squared score"""
        return r2_score(y_true, y_pred)
    
    def calculate_all_metrics(self, y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
        """Calculate all evaluation metrics"""
        metrics = {
            'RMSE': self.calculate_rmse(y_true, y_pred),
            'MAE': self.calculate_mae(y_true, y_pred),
            'MAPE': self.calculate_mape(y_true, y_pred),
            'Directional_Accuracy': self.calculate_directional_accuracy(y_true, y_pred),
            'R2': self.calculate_r2(y_true, y_pred)
        }
        return metrics
    
    def evaluate_model(self, model_name: str, y_true: np.ndarray, 
                      y_pred: np.ndarray) -> Dict[str, float]:
        """
        Evaluate a single model and store results
        
        Args:
            model_name: Name of the model
            y_true: True values
            y_pred: Predicted values
            
        Returns:
            Dictionary of metrics
        """
        metrics = self.calculate_all_metrics(y_true, y_pred)
        self.results[model_name] = metrics
        return metrics
    
    def evaluate_multiple_models(self, y_true: np.ndarray, 
                                 predictions: Dict[str, np.ndarray]) -> pd.DataFrame:
        """
        Evaluate multiple models
        
        Args:
            y_true: True values
            predictions: Dictionary of model_name -> predictions
            
        Returns:
            DataFrame with metrics for all models
        """
        results = []
        
        for model_name, y_pred in predictions.items():
            if y_pred is not None and len(y_pred) == len(y_true):
                metrics = self.calculate_all_metrics(y_true, y_pred)
                metrics['Model'] = model_name
                results.append(metrics)
        
        return pd.DataFrame(results)
    
    def rank_models(self, metric: str = 'RMSE', ascending: bool = True) -> pd.DataFrame:
        """
        Rank models by a specific metric
        
        Args:
            metric: Metric to rank by
            ascending: True for metrics where lower is better (RMSE, MAE)
            
        Returns:
            DataFrame with ranked models
        """
        if not self.results:
            return pd.DataFrame()
        
        df = pd.DataFrame(self.results).T
        df = df.sort_values(metric, ascending=ascending)
        df['Rank'] = range(1, len(df) + 1)
        
        return df
    
    def get_best_model(self, metric: str = 'RMSE') -> str:
        """Get name of best performing model"""
        if not self.results:
            return None
        
        # For RMSE, MAE, MAPE - lower is better
        if metric in ['RMSE', 'MAE', 'MAPE']:
            best_model = min(self.results.items(), 
                           key=lambda x: x[1][metric])[0]
        # For Directional_Accuracy, R2 - higher is better
        else:
            best_model = max(self.results.items(), 
                           key=lambda x: x[1][metric])[0]
        
        return best_model
    
    def plot_predictions_comparison(self, y_true: np.ndarray,
                                   predictions: Dict[str, np.ndarray],
                                   dates: pd.DatetimeIndex = None):
        """
        Create comparison plot of predictions
        (Returns data for plotting, actual plotting done in Streamlit)
        """
        plot_data = pd.DataFrame({'Actual': y_true}, 
                                index=dates if dates is not None else range(len(y_true)))
        
        for model_name, y_pred in predictions.items():
            if y_pred is not None and len(y_pred) == len(y_true):
                plot_data[model_name] = y_pred
        
        return plot_data
    
    def calculate_forecast_bias(self, y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Calculate forecast bias (mean error)"""
        return np.mean(y_pred - y_true)
    
    def calculate_theil_u(self, y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """
        Calculate Theil's U statistic
        U < 1: forecast is better than naive forecast
        U = 1: forecast is as good as naive forecast
        U > 1: forecast is worse than naive forecast
        """
        naive_forecast = np.roll(y_true, 1)[1:]  # Previous value as forecast
        y_true_trimmed = y_true[1:]
        y_pred_trimmed = y_pred[1:]
        
        numerator = np.sqrt(np.mean((y_true_trimmed - y_pred_trimmed) ** 2))
        denominator = np.sqrt(np.mean((y_true_trimmed - naive_forecast) ** 2))
        
        if denominator == 0:
            return np.inf
        
        return numerator / denominator